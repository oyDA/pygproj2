from pygame import *
import pyganim
import os

ANIMAL_WIDTH = 145
ANIMAL_HEIGHT = 78
movespeed = 3
ANIMAL_COLOR = "#2110FF"
ICON_DIR = os.path.dirname(__file__)


ANIMATION_ANIMAL_SRIGHT = [('%s/tiger/SRight1.png' % ICON_DIR),
                           ('%s/tiger/SRight2.png' % ICON_DIR)]
ANIMATION_ANIMAL_SLEFT = [('%s/tiger/SLeft1.png' % ICON_DIR),
                          ('%s/tiger/SLeft2.png' % ICON_DIR)]
ANIMATION_ANIMAL_RIGHT = [('%s/tiger/Right1.png' % ICON_DIR),
                          ('%s/tiger/Right2.png' % ICON_DIR)]
ANIMATION_ANIMAL_LEFT = [('%s/tiger/Left1.png' % ICON_DIR),
                         ('%s/tiger/Left2.png' % ICON_DIR)]



class Tiger(sprite.Sprite):
    def __init__(self, x, y):
        sprite.Sprite.__init__(self)
        self.startX = x
        self.startY = y
        self.xvel = 0
        self.yvel = 0
        self.image = Surface((ANIMAL_WIDTH, ANIMAL_HEIGHT))
        self.image.fill(Color(ANIMAL_COLOR))
        self.rect = Rect(x, y, ANIMAL_WIDTH, ANIMAL_HEIGHT)
        self.image.set_colorkey(Color(ANIMAL_COLOR))

        boltAnimSL = []
        for anim in ANIMATION_ANIMAL_SLEFT:
            boltAnimSL.append((anim, 0.5))
        self.boltAnimSL = pyganim.PygAnimation(boltAnimSL)
        self.boltAnimSL.play()

        boltAnimSR = []
        for anim in ANIMATION_ANIMAL_SRIGHT:
            boltAnimSR.append((anim, 0.5))
        self.boltAnimSR = pyganim.PygAnimation(boltAnimSR)
        self.boltAnimSR.play()

        boltAnimL = []
        for anim in ANIMATION_ANIMAL_LEFT:
            boltAnimL.append((anim, 0.5))
        self.boltAnimL = pyganim.PygAnimation(boltAnimL)
        self.boltAnimL.play()

        boltAnimR = []
        for anim in ANIMATION_ANIMAL_RIGHT:
            boltAnimR.append((anim, 0.5))
        self.boltAnimR = pyganim.PygAnimation(boltAnimR)
        self.boltAnimR.play()

    def update(self, action, platforms):
        if self.xvel == movespeed:
            self.image.fill(Color(ANIMAL_COLOR))
            self.boltAnimL.blit(self.image, (-30, -35))
        elif self.xvel == -movespeed:
            self.image.fill(Color(ANIMAL_COLOR))
            self.boltAnimR.blit(self.image, (-16, -35))

        self.xvel = -movespeed

        self.rect.x += self.xvel
        self.collide(self.xvel, 0, platforms)
        self.rect.y += self.yvel
        self.collide(0, self.yvel, platforms)


    def collide(self, xvel, yvel, platforms):
        for p in platforms:
            if sprite.collide_rect(self, p):
                if xvel > 0:
                    self.rect.right = p.rect.left
                if xvel < 0:
                    self.rect.left = p.rect.right

