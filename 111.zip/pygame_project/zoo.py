import pygame
import math
from math import *
from playerupd import *
from blocks import *
from monsters import *
import time


WIN_WIDTH = 1000
WIN_HEIGHT = 750
DISPLAY = (WIN_WIDTH, WIN_HEIGHT)
BACKGROUND_COLOR = "#A00000"

FILE_DIR = os.path.dirname(__file__)


class Camera(object):
    def __init__(self, camera_func, width, height):
        self.camera_func = camera_func
        self.state = Rect(0, 0, width, height)

    def apply(self, target):
        return target.rect.move(self.state.topleft)

    def update(self, target):
        self.state = self.camera_func(self.state, target.rect)


def camera_configure(camera, target_rect):
    l, t, _, _ = target_rect
    _, _, w, h = camera
    l, t = -l + WIN_WIDTH / 2, -t + WIN_HEIGHT / 2

    l = min(0, l)
    l = max(-(camera.width - WIN_WIDTH), l)
    t = max(-(camera.height - WIN_HEIGHT), t)
    t = min(0, t)

    return Rect(l, t, w, h)


def loadLevel():
    global playerX, playerY
    global animalX, animalY

    levelFile = open(r'''lvls/lvl.txt''')
    line = " "
    while line[0] != "/":
        line = levelFile.readline()
        if line[0] == "[":
            while line[0] != "]":
                line = levelFile.readline()
                if line[0] != "]":
                    endLine = line.find("|")
                    level.append(line[0: endLine])
        if line[0] != "":
            commands = line.split()
            if len(commands) > 1:
                if commands[0] == "player":
                    playerX = int(commands[1])
                    playerY = int(commands[2])
                if commands[0] == "portal":
                    tp = BlockTeleport(int(commands[1]), int(commands[2]), int(commands[3]), int(commands[4]))
                    entities.add(tp)
                    platforms.append(tp)
                    animatedEntities.add(tp)
                if commands[0] == "monster":  # тут надо поменять саму концепцию и сделать как у player
                    animalX = int(commands[1])
                    animalY = int(commands[2])
                    an = Tiger(animalX, animalY)
                    platforms.append(an)
 #                  mn = Animal(int(commands[1]), int(commands[2]))  # тут надо поменять саму концепцию и сделать как у player
 #                  entities.add(mn)  # тут надо поменять саму концепцию и сделать как у player
 #                  platforms.append(mn)  # тут надо поменять саму концепцию и сделать как у player
 #                  monsters.add(mn)  # тут надо поменять саму концепцию и сделать как у player


def rect_distance(rect1, rect2):
    px1 = rect1.topleft[0]
    ax1 = rect2.topleft[0]
    py1 = rect1.topleft[1]
    ay1 = rect2.topleft[1]
    px2 = rect1.bottomright[0]
    py2 = rect1.bottomright[1]
    ax2 = rect2.bottomright[0]
    ay2 = rect2.bottomright[1]
    px3 = rect1.topright[0]
    py3 = rect1.topright[1]
    px4 = rect1.bottomleft[0]
    py4 = rect1.bottomleft[1]
    ax3 = rect2.topright[0]
    ay3 = rect2.topright[1]
    ax4 = rect2.bottomleft[0]
    ay4 = rect2.bottomleft[1]
    if (-60 < px2 - ax1 < 60 and -60 < py2 - ay1 < 60) or (-60 < px1 - ax2 < 60 and -60 < py1 - ay2 < 60) or \
       (-60 < px4 - ax3 < 60 and -60 < py4 - ay3 < 60) or (-60 < px3 - ax4 < 60 and -60 < py3 - ay4 < 60) or \
       (ax1 < px2 < ax3 and -30 < py2 - ay1 < 30) or (ax4 < px1 < ax2 and -30 < py1 - ay4 < 30) or \
       (ay3 < py1 < ay2 and -20 < px1 - ax3 < 20):
        print('122323')
        print(px2, py2, ax1, ay1)
        return True
    print(123142, '123ewrw')



def main():
    loadLevel()
    pygame.init()
    screen = pygame.display.set_mode(DISPLAY)
    pygame.display.set_caption("ZoZoo")

    bg = Surface((WIN_WIDTH, WIN_HEIGHT))
    bg.fill(Color(BACKGROUND_COLOR))

    left = right = False
    up = down = False
    running = False
    action = False

    timer = pygame.time.Clock()
    x = y = 0
    for row in level:
        for col in row:
            if col == "-":
                pf = Platform(x, y)
                entities.add(pf)
                platforms.append(pf)
            if col == "*":
                bd = BlockDie(x, y)
                entities.add(bd)
                platforms.append(bd)
            if col == "T":
                pr = Grass(x, y)
                entities.add(pr)
                platforms.append(pr)
                animatedEntities.add(pr)
            if col == "F":
                pr = Fence(x, y)
                entities.add(pr)
                platforms.append(pr)
                animatedEntities.add(pr)
            x += PLATFORM_WIDTH
        y += PLATFORM_HEIGHT
        x = 0

    hero = Player(playerX, playerY)
    entities.add(hero)

    tiger = Tiger(animalX, animalY)
    entities.add(tiger)

    total_level_width = len(level[0]) * PLATFORM_WIDTH
    total_level_height = len(level) * PLATFORM_HEIGHT

    camera = Camera(camera_configure, total_level_width, total_level_height)

    done = False

    while not done:
        timer.tick(60)
        for e in pygame.event.get():
            if e.type == QUIT:
                done = True
            if e.type == KEYDOWN and e.key == K_w:
                up = True
            if e.type == KEYDOWN and e.key == K_a:
                left = True
            if e.type == KEYDOWN and e.key == K_d:
                right = True
            if e.type == KEYDOWN and e.key == K_s:
                down = True
            if e.type == KEYDOWN and e.key == K_LSHIFT:
                running = True
            if e.type == KEYUP and e.key == K_w:
                up = False
            if e.type == KEYUP and e.key == K_s:
                down = False
            if e.type == KEYUP and e.key == K_d:
                right = False
            if e.type == KEYUP and e.key == K_a:
                left = False
            if e.type == KEYUP and e.key == K_LSHIFT:
                running = False
            if e.type == KEYDOWN and e.key == K_e and rect_distance(hero.rect, tiger.rect):
                action = True
                time.sleep(0.5)
            if e.type == KEYUP and e.key == K_e:
                action = False

        screen.blit(bg, (0, 0))
        hero.update(left, right, up, down, running, platforms)
        camera.update(hero)
        tiger.update(action, platforms)
        animatedEntities.update(platforms)
        for e in entities:
            screen.blit(e.image, camera.apply(e))
        pygame.display.update()


level = []
entities = pygame.sprite.Group()
animatedEntities = pygame.sprite.Group()
platforms = []
if __name__ == "__main__":
    main()
