from pygame import *
import pyganim
import os

ANIMAL_WIDTH = 32
ANIMAL_HEIGHT = 32
ANIMAL_COLOR = "#2110FF"
ICON_DIR = os.path.dirname(__file__)


ANIMATION_ANIMAL = [('%s/monsters/fire1.png' % ICON_DIR),
                      ('%s/monsters/fire2.png' % ICON_DIR )]

class Animal(sprite.Sprite):
    def __init__(self, x, y):
        sprite.Sprite.__init__(self)
        self.image = Surface((ANIMAL_WIDTH, ANIMAL_HEIGHT))
        self.image.fill(Color(ANIMAL_COLOR))
        self.rect = Rect(x, y, ANIMAL_WIDTH, ANIMAL_HEIGHT)
        self.image.set_colorkey(Color(ANIMAL_COLOR))
        self.startX = x
        self.startY = y
        boltAnim = []
        for anim in ANIMATION_ANIMAL:
            boltAnim.append((anim, 0.3))
        self.boltAnim = pyganim.PygAnimation(boltAnim)
        self.boltAnim.play()
         
    def update(self, platforms):
        self.image.fill(Color(ANIMAL_COLOR))
        self.boltAnim.blit(self.image, (0, 0))

