from pygame import *
import pyganim
import os
import blocks

MOVE_SPEED = 5
MOVE_EXTRA_SPEED = 7
WIDTH = 100
HEIGHT = 100
COLOR = "#888888"
ANIMATION_DELAY = 0.15
ANIMATION_SUPER_SPEED_DELAY = 0.1
ICON_DIR = os.path.dirname(__file__)

ANIMATION_RIGHT = [('%s/character/r1.png' % ICON_DIR),
                   ('%s/character/r2.png' % ICON_DIR),
                   ('%s/character/r3.png' % ICON_DIR),
                   ('%s/character/r4.png' % ICON_DIR),
                   ('%s/character/r5.png' % ICON_DIR),
                   ('%s/character/r6.png' % ICON_DIR)]
ANIMATION_LEFT = [('%s/character/l1.png' % ICON_DIR),
                  ('%s/character/l2.png' % ICON_DIR),
                  ('%s/character/l3.png' % ICON_DIR),
                  ('%s/character/l4.png' % ICON_DIR),
                  ('%s/character/l5.png' % ICON_DIR),
                  ('%s/character/l6.png' % ICON_DIR)]
ANIMATION_STAY = [('%s/character/s1.png' % ICON_DIR, 0.1)]
ANIMATION_FORWARD = [('%s/character/f1.png' % ICON_DIR),
                     ('%s/character/f2.png' % ICON_DIR),
                     ('%s/character/f3.png' % ICON_DIR),
                     ('%s/character/f4.png' % ICON_DIR),
                     ('%s/character/f5.png' % ICON_DIR),
                     ('%s/character/f6.png' % ICON_DIR),
                     ('%s/character/f7.png' % ICON_DIR),
                     ('%s/character/f8.png' % ICON_DIR)]
ANIMATION_BACK = [('%s/character/s1.png' % ICON_DIR),
                  ('%s/character/s2.png' % ICON_DIR),
                  ('%s/character/s3.png' % ICON_DIR),
                  ('%s/character/s4.png' % ICON_DIR),
                  ('%s/character/s5.png' % ICON_DIR),
                  ('%s/character/s6.png' % ICON_DIR)]


class Player(sprite.Sprite):
    def __init__(self, x, y):
        sprite.Sprite.__init__(self)
        self.xvel = 0
        self.startX = x
        self.startY = y
        self.yvel = 0
        self.onGround = False
        self.image = Surface((WIDTH, HEIGHT))
        self.image.fill(Color(COLOR))
        self.rect = Rect(x, y, WIDTH, HEIGHT)
        self.image.set_colorkey(Color(COLOR))

        boltAnim = []
        boltAnimSuperSpeed = []
        for anim in ANIMATION_RIGHT:
            boltAnim.append((anim, ANIMATION_DELAY))
            boltAnimSuperSpeed.append((anim, ANIMATION_SUPER_SPEED_DELAY))
        self.boltAnimRight = pyganim.PygAnimation(boltAnim)
        self.boltAnimRight.play()
        self.boltAnimRightSuperSpeed = pyganim.PygAnimation(boltAnimSuperSpeed)
        self.boltAnimRightSuperSpeed.play()

        boltAnim = []
        boltAnimSuperSpeed = []
        for anim in ANIMATION_LEFT:
            boltAnim.append((anim, ANIMATION_DELAY))
            boltAnimSuperSpeed.append((anim, ANIMATION_SUPER_SPEED_DELAY))
        self.boltAnimLeft = pyganim.PygAnimation(boltAnim)
        self.boltAnimLeft.play()
        self.boltAnimLeftSuperSpeed = pyganim.PygAnimation(boltAnimSuperSpeed)
        self.boltAnimLeftSuperSpeed.play()

        boltAnim = []
        boltAnimSuperSpeed = []
        for anim in ANIMATION_FORWARD:
            boltAnim.append((anim, ANIMATION_DELAY))
            boltAnimSuperSpeed.append((anim, ANIMATION_SUPER_SPEED_DELAY))
        self.boltAnimForward = pyganim.PygAnimation(boltAnim)
        self.boltAnimForward.play()
        self.boltAnimForwardSuperSpeed = pyganim.PygAnimation(boltAnimSuperSpeed)
        self.boltAnimForwardSuperSpeed.play()

        boltAnim = []
        boltAnimSuperSpeed = []
        for anim in ANIMATION_BACK:
            boltAnim.append((anim, ANIMATION_DELAY))
            boltAnimSuperSpeed.append((anim, ANIMATION_SUPER_SPEED_DELAY))
        self.boltAnimBack = pyganim.PygAnimation(boltAnim)
        self.boltAnimBack.play()
        self.boltAnimBackSuperSpeed = pyganim.PygAnimation(boltAnimSuperSpeed)
        self.boltAnimBackSuperSpeed.play()

        self.boltAnimStay = pyganim.PygAnimation(ANIMATION_STAY)
        self.boltAnimStay.play()
        self.boltAnimStay.blit(self.image, (0, 0))

        self.boltAnimStay = pyganim.PygAnimation(ANIMATION_STAY)
        self.boltAnimStay.play()
        self.boltAnimStay.blit(self.image, (0, 0))

    def update(self, left, right, up, down, running, platforms):
        if up:
            self.yvel = -MOVE_SPEED
            self.image.fill(Color(COLOR))
            if running:
                self.yvel = -MOVE_EXTRA_SPEED
                self.boltAnimForwardSuperSpeed.blit(self.image, (0, 0))
            else:
                self.boltAnimForward.blit(self.image, (0, 0))

        if down:
            self.yvel = MOVE_SPEED
            self.image.fill(Color(COLOR))
            if running:
                self.yvel = MOVE_EXTRA_SPEED
                self.boltAnimBackSuperSpeed.blit(self.image, (0, 0))
            else:
                self.boltAnimBack.blit(self.image, (0, 0))

        if left:
            self.xvel = -MOVE_SPEED
            self.image.fill(Color(COLOR))
            if running:
                self.xvel = -MOVE_EXTRA_SPEED
                self.boltAnimLeftSuperSpeed.blit(self.image, (0, 0))
            else:
                self.boltAnimLeft.blit(self.image, (0, 0))

        if right:
            self.xvel = MOVE_SPEED
            self.image.fill(Color(COLOR))
            if running:
                self.xvel = MOVE_EXTRA_SPEED
                self.boltAnimRightSuperSpeed.blit(self.image, (0, 0))
            else:
                self.boltAnimRight.blit(self.image, (0, 0))

        if not (left or right):
            self.xvel = 0
        if not (up or down):
            self.yvel = 0
#      if not (up or down or left or right):
#          self.image.fill(Color(COLOR))
#          self.boltAnimStay.blit(self.image, (0, 0))

        self.rect.y += self.yvel
        self.collide(0, self.yvel, platforms)

        self.rect.x += self.xvel
        self.collide(self.xvel, 0, platforms)

    def collide(self, xvel, yvel, platforms):
        for p in platforms:
            if sprite.collide_rect(self, p):
                if isinstance(p, blocks.BlockTeleport):
                    self.teleporting(p.goX, p.goY)
                elif not isinstance(p, blocks.Grass):
                    if xvel > 0:
                        self.rect.right = p.rect.left
                    if xvel < 0:
                        self.rect.left = p.rect.right
                    if yvel > 0:
                        self.rect.bottom = p.rect.top
                        self.yvel = 0
                    if yvel < 0:
                        self.rect.top = p.rect.bottom
                        self.yvel = 0

    def teleporting(self, goX, goY):
        self.rect.x = goX
        self.rect.y = goY