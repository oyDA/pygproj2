import pygame
from math import *
from playerupd import *
from blocks import *
from monsters import *

WIN_WIDTH = 1000
WIN_HEIGHT = 750
DISPLAY = (WIN_WIDTH, WIN_HEIGHT)
BACKGROUND_COLOR = "#000000"

FILE_DIR = os.path.dirname(__file__)


class Camera(object):
    def __init__(self, camera_func, width, height):
        self.camera_func = camera_func
        self.state = Rect(0, 0, width, height)

    def apply(self, target):
        return target.rect.move(self.state.topleft)

    def update(self, target):
        self.state = self.camera_func(self.state, target.rect)


def camera_configure(camera, target_rect):
    l, t, _, _ = target_rect
    _, _, w, h = camera
    l, t = -l + WIN_WIDTH / 2, -t + WIN_HEIGHT / 2

    l = min(0, l)
    l = max(-(camera.width - WIN_WIDTH), l)
    t = max(-(camera.height - WIN_HEIGHT), t)
    t = min(0, t)

    return Rect(l, t, w, h)


def loadLevel():
    global playerX, playerY

    levelFile = open(r'''C:\Users\1\Desktop\project\lvls\lvl.txt''')
    line = " "
    while line[0] != "/":
        line = levelFile.readline()
        if line[0] == "[":
            while line[0] != "]":
                line = levelFile.readline()
                if line[0] != "]":
                    endLine = line.find("|")
                    level.append(line[0: endLine])
        if line[0] != "":
            commands = line.split()
            if len(commands) > 1:
                if commands[0] == "player":
                    playerX = int(commands[1])
                    playerY = int(commands[2])
                if commands[0] == "portal":
                    tp = BlockTeleport(int(commands[1]), int(commands[2]), int(commands[3]), int(commands[4]))
                    entities.add(tp)
                    platforms.append(tp)
                    animatedEntities.add(tp)
                if commands[0] == "monster":
                    mn = Animal(int(commands[1]), int(commands[2]))
                    entities.add(mn)
                    platforms.append(mn)
                    monsters.add(mn)


def rect_distance(rect1, rect2):
    x1, y1 = rect1.topleft
    x1b, y1b = rect1.bottomright
    x2, y2 = rect2.topleft
    x2b, y2b = rect2.bottomright
    Dleft = x2b < x1
    Dright = x1b < x2
    Dtop = y2b < y1
    Dbottom = y1b < y2
    if Dbottom and Dleft:
        print('bottom left')
        return math.hypot(x2b - x1, y2 - y1b)
    elif Dleft and Dtop:
        print('top left')
        return math.hypot(x2b - x1, y2b - y1)
    elif Dtop and Dright:
        print('top right')
        return math.hypot(x2 - x1b, y2b - y1)
    elif Dright and Dbottom:
        print('bottom right')
        return math.hypot(x2 - x1b, y2 - y1b)
    elif Dleft:
        print('left')
        return x1 - x2b
    elif Dright:
        print('right')
        return x2 - x1b
    elif Dtop:
        print('top')
        return y1 - y2b
    elif Dbottom:
        print('bottom')
        return y2 - y1b
    else:
        print('intersection')
        return 0.


def main():
    loadLevel()
    pygame.init()
    screen = pygame.display.set_mode(DISPLAY)
    pygame.display.set_caption("ZoZoo")

    bg = Surface((WIN_WIDTH, WIN_HEIGHT))
    bg.fill(Color(BACKGROUND_COLOR))

    left = right = False
    up = down = False
    running = False

    timer = pygame.time.Clock()
    x = y = 0
    for row in level:
        for col in row:
            if col == "-":
                pf = Platform(x, y)
                entities.add(pf)
                platforms.append(pf)
            if col == "*":
                bd = BlockDie(x, y)
                entities.add(bd)
                platforms.append(bd)
            if col == "T":
                pr = Grass(x, y)
                entities.add(pr)
                platforms.append(pr)
                animatedEntities.add(pr)
            x += PLATFORM_WIDTH
        y += PLATFORM_HEIGHT
        x = 0

    hero = Player(playerX, playerY)
    entities.add(hero)

    #    animal = Animal(ax, ay)

    total_level_width = len(level[0]) * PLATFORM_WIDTH
    total_level_height = len(level) * PLATFORM_HEIGHT

    camera = Camera(camera_configure, total_level_width, total_level_height)

    done = False

    while not done:
        timer.tick(60)
        action = False
        for e in pygame.event.get():
            if e.type == QUIT:
                done = True
            if e.type == KEYDOWN and e.key == K_w:
                up = True
            if e.type == KEYDOWN and e.key == K_a:
                left = True
            if e.type == KEYDOWN and e.key == K_d:
                right = True
            if e.type == KEYDOWN and e.key == K_s:
                down = True
            if e.type == KEYDOWN and e.key == K_LSHIFT:
                running = True
            if e.type == KEYUP and e.key == K_w:
                up = False
            if e.type == KEYUP and e.key == K_s:
                down = False
            if e.type == KEYUP and e.key == K_d:
                right = False
            if e.type == KEYUP and e.key == K_a:
                left = False
            if e.type == KEYUP and e.key == K_LSHIFT:
                running = False
        #            if e.type == KEYDOWN and e.key == K_e and rect_distance(hero.rect, Animal.rect) < 20:
        #                action = True

        screen.blit(bg, (0, 0))
        hero.update(left, right, up, down, running, platforms)
        camera.update(hero)
        animatedEntities.update()
        monsters.update(platforms)
        for e in entities:
            screen.blit(e.image, camera.apply(e))

        pygame.display.update()


level = []
entities = pygame.sprite.Group()
animatedEntities = pygame.sprite.Group()
monsters = pygame.sprite.Group()
platforms = []
if __name__ == "__main__":
    main()
