import pygame
from random import randrange as rnd

class Arkanoid:

    def __init__(self):
        self.WIDTH, self.HEIGHT = 1200, 700
        self.fps = 60
        pygame.display.set_caption('Arkanoid')
        # наша платформа
        self.paddle_w = 330
        self.paddle_h = 35
        self.paddle_speed = 15
        self.paddle = pygame.Rect(self.WIDTH // 2 - self.paddle_w // 2, self.HEIGHT - self.paddle_h - 10, self.paddle_w, self.paddle_h)
        # мяч
        self.ball_radius = 20
        self.ball_speed = 6
        self.ball_rect = int(self.ball_radius * 2 ** 0.5)
        self.ball = pygame.Rect(rnd(self.ball_rect, self.WIDTH - self.ball_rect), self.HEIGHT // 2, self.ball_rect, self.ball_rect)
        self.dx, self.dy = 1, -1
        # блоки
        self.block_list = [pygame.Rect(10 + 120 * i, 10 + 70 * j, 100, 50) for i in range(10) for j in range(4)]
        self.color_list = [(rnd(30, 256), rnd(30, 256), rnd(30, 256)) for i in range(10) for j in range(4)]

        pygame.init()
        self.sc = pygame.display.set_mode((self.WIDTH, self.HEIGHT))
        self.clock = pygame.time.Clock()
        # фон
        self.img = pygame.image.load('1.jpg').convert()

        self.play()


    def detect_collision(self, dx, dy, ball, rect):
        self.dx = dx
        self.dy = dy
        self.ball = ball
        self.rect = rect
        if self.dx > 0:
            self.delta_x = self.ball.right - self.rect.left
        else:
            self.delta_x = self.rect.right - self.ball.left
        if dy > 0:
            self.delta_y = self.ball.bottom - self.rect.top
        else:
            self.delta_y = self.rect.bottom - self.ball.top

        if abs(self.delta_x - self.delta_y) < 10:
            self.dx, self.dy = -self.dx, -self.dy
        elif self.delta_x > self.delta_y:
            self.dy = -self.dy
        elif self.delta_y > self.delta_x:
            self.dx = -self.dx
        return self.dx, self.dy

    def play(self):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    exit()
            self.sc.blit(self.img, (0, 0))
            # рисуем
            [pygame.draw.rect(self.sc, self.color_list[color], block) for color, block in enumerate(self.block_list)]
            pygame.draw.rect(self.sc, pygame.Color('darkorange'), self.paddle)
            pygame.draw.circle(self.sc, pygame.Color('white'), self.ball.center, self.ball_radius)
            # движения мяча
            self.ball.x += self.ball_speed * self.dx
            self.ball.y += self.ball_speed * self.dy
            # коллизия по сторонам
            if self.ball.centerx < self.ball_radius or self.ball.centerx > self.WIDTH - self.ball_radius:
                self.dx = -self.dx
            # коллизия сверху
            if self.ball.centery < self.ball_radius:
                self.dy = -self.dy
            # коллизия платформы
            if self.ball.colliderect(self.paddle) and self.dy > 0:
                self.dx, self.dy = self.detect_collision(self.dx, self.dy, self.ball, self.paddle)
            # коллизия блоков
            self.hit_index = self.ball.collidelist(self.block_list)
            if self.hit_index != -1:
                self.hit_rect = self.block_list.pop(self.hit_index)
                self.hit_color = self.color_list.pop(self.hit_index)
                self.dx, self.dy = self.detect_collision(self.dx, self.dy, self.ball, self.hit_rect)
                # специально
                self.hit_rect.inflate_ip(self.ball.width * 3, self.ball.height * 3)
                pygame.draw.rect(self.sc, self.hit_color, self.hit_rect)
                self.fps += 2
            # победа/поражение
            if self.ball.bottom > self.HEIGHT:
                print('GAME OVER!')
                exit()
            elif not len(self.block_list):
                print('YOU WIN!!!')
                exit()
            # контроль
            self.key = pygame.key.get_pressed()
            if self.key[pygame.K_LEFT] and self.paddle.left > 0:
                self.paddle.left -= self.paddle_speed
            if self.key[pygame.K_RIGHT] and self.paddle.right < self.WIDTH:
                self.paddle.right += self.paddle_speed
            # обновление экрана
            pygame.display.flip()
            self.clock.tick(self.fps)

Arkanoid()