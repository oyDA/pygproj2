def proga(q):
    w = [(int(q.split()[0])), (int(q.split()[1]))]
    w.sort()
    print((w[1] % w[0]) + 1)


proga('2 4')
proga('4 2')
proga('2 5')
